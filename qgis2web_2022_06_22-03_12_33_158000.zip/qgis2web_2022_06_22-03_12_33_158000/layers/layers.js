var wms_layers = [];
var baseLayer = new ol.layer.Group({
    'title': '',
    layers: [
new ol.layer.Tile({
    'title': 'OSM',
    'type': 'base',
    source: new ol.source.OSM()
})
]
});
var format_ADMINISTRASIKECAMATAN_AR_50K_0 = new ol.format.GeoJSON();
var features_ADMINISTRASIKECAMATAN_AR_50K_0 = format_ADMINISTRASIKECAMATAN_AR_50K_0.readFeatures(json_ADMINISTRASIKECAMATAN_AR_50K_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ADMINISTRASIKECAMATAN_AR_50K_0 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_ADMINISTRASIKECAMATAN_AR_50K_0.addFeatures(features_ADMINISTRASIKECAMATAN_AR_50K_0);var lyr_ADMINISTRASIKECAMATAN_AR_50K_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_ADMINISTRASIKECAMATAN_AR_50K_0, 
                style: style_ADMINISTRASIKECAMATAN_AR_50K_0,
    title: 'ADMINISTRASIKECAMATAN_AR_50K<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_0.png" /> BANDARSEIKIJANG<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_1.png" /> BUKITRAYA<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_2.png" /> KAMPARKIRI HILIR<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_3.png" /> KAMPARKIRI TENGAH<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_4.png" /> KERINCIKANAN<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_5.png" /> KOTOGASIB<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_6.png" /> LANGGAM<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_7.png" /> LIMAPULUH<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_8.png" /> LUBUKDALAM<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_9.png" /> MARPOYANDAMAI<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_10.png" /> MINAS<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_11.png" /> PAYUNGSEKAKI<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_12.png" /> PEKANBARUKOTA<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_13.png" /> PERHENTIANRAJA<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_14.png" /> RUMBAI<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_15.png" /> RUMBAIPESISIR<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_16.png" /> SAIL<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_17.png" /> SENAPELAN<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_18.png" /> SIAK HULU<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_19.png" /> SUKAJADI<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_20.png" /> TAMBANG<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_21.png" /> TAMPAN<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_22.png" /> TAPUNG<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_23.png" /> TAPUNG HILIR<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_24.png" /> TENAYANRAYA<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_25.png" /> TUALANG<br />\
    <img src="styles/legend/ADMINISTRASIKECAMATAN_AR_50K_0_26.png" /> <br />'
        });var format_htl3_1 = new ol.format.GeoJSON();
var features_htl3_1 = format_htl3_1.readFeatures(json_htl3_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_htl3_1 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_htl3_1.addFeatures(features_htl3_1);var lyr_htl3_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_htl3_1, 
                style: style_htl3_1,
                title: '<img src="styles/legend/htl3_1.png" /> htl3'
            });var format_sklh6_2 = new ol.format.GeoJSON();
var features_sklh6_2 = format_sklh6_2.readFeatures(json_sklh6_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_sklh6_2 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_sklh6_2.addFeatures(features_sklh6_2);var lyr_sklh6_2 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_sklh6_2, 
                style: style_sklh6_2,
                title: '<img src="styles/legend/sklh6_2.png" /> sklh6'
            });var format_rm_3 = new ol.format.GeoJSON();
var features_rm_3 = format_rm_3.readFeatures(json_rm_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_rm_3 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_rm_3.addFeatures(features_rm_3);var lyr_rm_3 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_rm_3, 
                style: style_rm_3,
                title: '<img src="styles/legend/rm_3.png" /> rm'
            });var format_shpsmp_4 = new ol.format.GeoJSON();
var features_shpsmp_4 = format_shpsmp_4.readFeatures(json_shpsmp_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_shpsmp_4 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_shpsmp_4.addFeatures(features_shpsmp_4);var lyr_shpsmp_4 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_shpsmp_4, 
                style: style_shpsmp_4,
                title: '<img src="styles/legend/shpsmp_4.png" /> shp smp'
            });

lyr_ADMINISTRASIKECAMATAN_AR_50K_0.setVisible(true);lyr_htl3_1.setVisible(true);lyr_sklh6_2.setVisible(true);lyr_rm_3.setVisible(true);lyr_shpsmp_4.setVisible(true);
var layersList = [baseLayer,lyr_ADMINISTRASIKECAMATAN_AR_50K_0,lyr_htl3_1,lyr_sklh6_2,lyr_rm_3,lyr_shpsmp_4];
lyr_ADMINISTRASIKECAMATAN_AR_50K_0.set('fieldAliases', {'KDPPUM': 'KDPPUM', 'NAMOBJ': 'NAMOBJ', 'REMARK': 'REMARK', 'KDPBPS': 'KDPBPS', 'FCODE': 'FCODE', 'LUASWH': 'LUASWH', 'UUPP': 'UUPP', 'SRS_ID': 'SRS_ID', 'LCODE': 'LCODE', 'METADATA': 'METADATA', 'KDEBPS': 'KDEBPS', 'KDEPUM': 'KDEPUM', 'KDCBPS': 'KDCBPS', 'KDCPUM': 'KDCPUM', 'KDBBPS': 'KDBBPS', 'KDBPUM': 'KDBPUM', 'WADMKD': 'WADMKD', 'WIADKD': 'WIADKD', 'WADMKC': 'WADMKC', 'WIADKC': 'WIADKC', 'WADMKK': 'WADMKK', 'WIADKK': 'WIADKK', 'WADMPR': 'WADMPR', 'WIADPR': 'WIADPR', 'TIPADM': 'TIPADM', 'SHAPE_Leng': 'SHAPE_Leng', 'SHAPE_Area': 'SHAPE_Area', });
lyr_htl3_1.set('fieldAliases', {'id': 'id', 'nama': 'nama', 'latitude': 'latitude', 'longitude': 'longitude', 'Alamat': 'Alamat', 'Name': 'Name', });
lyr_sklh6_2.set('fieldAliases', {'id': 'id', 'nama': 'nama', 'latitude': 'latitude', 'longitude': 'longitude', 'Alamat': 'Alamat', 'jam operas': 'jam operas', 'Name': 'Name', });
lyr_rm_3.set('fieldAliases', {'id': 'id', 'nama': 'nama', 'latitude': 'latitude', 'longitude': 'longitude', 'Alamat': 'Alamat', 'jam operas': 'jam operas', 'Name': 'Name', });
lyr_shpsmp_4.set('fieldAliases', {'id': 'id', 'nama': 'nama', 'latitude': 'latitude', 'longitude': 'longitude', 'Alamat': 'Alamat', 'Jam Operas': 'Jam Operas', 'Foto': 'Foto', });
lyr_ADMINISTRASIKECAMATAN_AR_50K_0.set('fieldImages', {'KDPPUM': 'TextEdit', 'NAMOBJ': 'TextEdit', 'REMARK': 'TextEdit', 'KDPBPS': 'TextEdit', 'FCODE': 'TextEdit', 'LUASWH': 'TextEdit', 'UUPP': 'TextEdit', 'SRS_ID': 'TextEdit', 'LCODE': 'TextEdit', 'METADATA': 'TextEdit', 'KDEBPS': 'TextEdit', 'KDEPUM': 'TextEdit', 'KDCBPS': 'TextEdit', 'KDCPUM': 'TextEdit', 'KDBBPS': 'TextEdit', 'KDBPUM': 'TextEdit', 'WADMKD': 'TextEdit', 'WIADKD': 'TextEdit', 'WADMKC': 'TextEdit', 'WIADKC': 'TextEdit', 'WADMKK': 'TextEdit', 'WIADKK': 'TextEdit', 'WADMPR': 'TextEdit', 'WIADPR': 'TextEdit', 'TIPADM': 'TextEdit', 'SHAPE_Leng': 'TextEdit', 'SHAPE_Area': 'TextEdit', });
lyr_htl3_1.set('fieldImages', {'id': 'TextEdit', 'nama': 'TextEdit', 'latitude': 'TextEdit', 'longitude': 'TextEdit', 'Alamat': 'TextEdit', 'Name': 'Photo', });
lyr_sklh6_2.set('fieldImages', {'id': 'TextEdit', 'nama': 'TextEdit', 'latitude': 'TextEdit', 'longitude': 'TextEdit', 'Alamat': 'TextEdit', 'jam operas': 'TextEdit', 'Name': 'Photo', });
lyr_rm_3.set('fieldImages', {'id': 'TextEdit', 'nama': 'TextEdit', 'latitude': 'TextEdit', 'longitude': 'TextEdit', 'Alamat': 'TextEdit', 'jam operas': 'TextEdit', 'Name': 'Photo', });
lyr_shpsmp_4.set('fieldImages', {'id': 'TextEdit', 'nama': 'TextEdit', 'latitude': 'TextEdit', 'longitude': 'TextEdit', 'Alamat': 'TextEdit', 'Jam Operas': 'TextEdit', 'Foto': 'Photo', });
lyr_ADMINISTRASIKECAMATAN_AR_50K_0.set('fieldLabels', {'KDPPUM': 'no label', 'NAMOBJ': 'no label', 'REMARK': 'no label', 'KDPBPS': 'no label', 'FCODE': 'no label', 'LUASWH': 'no label', 'UUPP': 'no label', 'SRS_ID': 'no label', 'LCODE': 'no label', 'METADATA': 'no label', 'KDEBPS': 'no label', 'KDEPUM': 'no label', 'KDCBPS': 'no label', 'KDCPUM': 'no label', 'KDBBPS': 'no label', 'KDBPUM': 'no label', 'WADMKD': 'no label', 'WIADKD': 'no label', 'WADMKC': 'no label', 'WIADKC': 'no label', 'WADMKK': 'no label', 'WIADKK': 'no label', 'WADMPR': 'no label', 'WIADPR': 'no label', 'TIPADM': 'no label', 'SHAPE_Leng': 'no label', 'SHAPE_Area': 'no label', });
lyr_htl3_1.set('fieldLabels', {'id': 'no label', 'nama': 'no label', 'latitude': 'no label', 'longitude': 'no label', 'Alamat': 'no label', 'Name': 'no label', });
lyr_sklh6_2.set('fieldLabels', {'id': 'no label', 'nama': 'no label', 'latitude': 'no label', 'longitude': 'no label', 'Alamat': 'no label', 'jam operas': 'no label', 'Name': 'no label', });
lyr_rm_3.set('fieldLabels', {'id': 'no label', 'nama': 'no label', 'latitude': 'no label', 'longitude': 'no label', 'Alamat': 'no label', 'jam operas': 'no label', 'Name': 'no label', });
lyr_shpsmp_4.set('fieldLabels', {'id': 'header label', 'nama': 'no label', 'latitude': 'no label', 'longitude': 'no label', 'Alamat': 'no label', 'Jam Operas': 'no label', 'Foto': 'no label', });
lyr_shpsmp_4.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});