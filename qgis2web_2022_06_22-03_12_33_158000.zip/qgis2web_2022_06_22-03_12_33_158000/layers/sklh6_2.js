var json_sklh6_2 = {
"type": "FeatureCollection",
"name": "sklh6_2",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "1", "nama": "SMAN 1 PEKANBARU", "latitude": 0.5259, "longitude": 101.45414, "Alamat": "Jl. Sultan Syarif Qasim No.159 Rintis Kec. Lima Puluh Kota Pekanbaru Riau 28156", "jam operas": "senin-jum'at", "Name": "sma1.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.45414, 0.5259 ] } },
{ "type": "Feature", "properties": { "id": "2", "nama": "SMAN 2 PEKANBARU", "latitude": 0.52141, "longitude": 101.43148, "Alamat": "Jl. Nusa Indah No.4 Labuh Baru Tim. Kec. Payung Sekaki Kota Pekanbaru Riau 28156", "jam operas": "senin-jum'at", "Name": "sma2.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.43148, 0.52141 ] } },
{ "type": "Feature", "properties": { "id": "3", "nama": "SMAN 3 PEKANBARU", "latitude": 0.57241, "longitude": 101.42869, "Alamat": "Jl. Yos Sudarso No.100A Umban Sari Kec. Rumbai Kota Pekanbaru Riau 28266", "jam operas": "senin-jum'at", "Name": "sma3.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.42869, 0.57241 ] } },
{ "type": "Feature", "properties": { "id": "4", "nama": "SMAN 4 PEKANBARU", "latitude": 0.4711, "longitude": 101.46212, "Alamat": "Jl. Adi Sucipto No.67 Maharatu Kec. Marpoyan Damai Kota Pekanbaru Riau 28289", "jam operas": "senin-jum'at", "Name": "sma4.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.46212, 0.4711 ] } },
{ "type": "Feature", "properties": { "id": "5", "nama": "SMAN 5 PEKANBARU", "latitude": 0.50474, "longitude": 101.44306, "Alamat": "Jl. Bawal No.43 Wonorejo Kec. Marpoyan Damai Kota Pekanbaru Riau 28125", "jam operas": "senin-jum'at", "Name": "sma5.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.44306, 0.50474 ] } }
]
}
