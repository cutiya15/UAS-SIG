var json_htl3_1 = {
"type": "FeatureCollection",
"name": "htl3_1",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "1", "nama": "The Premiere Hotel Pekanbaru", "latitude": 0.51308116659372704, "longitude": 101.448761840949, "Alamat": "Jl. Jend. Sudirman No.389 Simpang Empat Kec. Pekanbaru Kota Kota Pekanbaru Riau 28121", "Name": "h1.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.448761840949004, 0.513081166593727 ] } },
{ "type": "Feature", "properties": { "id": "2", "nama": "Hotel Aryaduta Pekanbaru", "latitude": 0.515567, "longitude": 101.4486065, "Alamat": "Jl. Diponegoro No.34 Simpang Empat Kec. Pekanbaru Kota Kota Pekanbaru Riau 28116", "Name": "h2.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.4486065, 0.515567 ] } },
{ "type": "Feature", "properties": { "id": "3", "nama": "Hotel Pangeran", "latitude": 0.50487835328893604, "longitude": 101.4528868102598, "Alamat": "Jl. Jend. Sudirman No.371-373 Cinta Raja Kec. Sail Kota Pekanbaru Riau 28126", "Name": "h3.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.452886810259798, 0.504878353288936 ] } },
{ "type": "Feature", "properties": { "id": "4", "nama": "Hotel Mutiara Merdeka", "latitude": 0.53732725054649799, "longitude": 101.43601112560428, "Alamat": "Jalan Yos Sudarso No.12-A Kampung Bandar Kp. Baru Kec. Senapelan Kota Pekanbaru Riau 28154", "Name": "h4.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.436011125604281, 0.537327250546498 ] } },
{ "type": "Feature", "properties": { "id": "5", "nama": "Hotel Parma Star", "latitude": 0.49730975260475901, "longitude": 101.455234039096, "Alamat": "FFW4+Q4R Tengkerang Tengah Kec. Marpoyan Damai Kota Pekanbaru Riau 28128", "Name": "h5.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.455234039095998, 0.497309752604759 ] } }
]
}
