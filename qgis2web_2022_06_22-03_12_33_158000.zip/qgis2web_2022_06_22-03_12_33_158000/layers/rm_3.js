var json_rm_3 = {
"type": "FeatureCollection",
"name": "rm_3",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "1", "nama": "Rumah Makan Dendeng Batokok (Sejak 1972)", "latitude": 0.50027218189357003, "longitude": 101.45638861025981, "Alamat": "Jl. Jati No.6 Tengkerang Utara Kec. Bukit Raya Kota Pekanbaru Riau 28128", "jam operas": "senin-jum'at", "Name": "ru1.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.456388610259808, 0.50027218189357 ] } },
{ "type": "Feature", "properties": { "id": "2", "nama": "Rumah Makan Bebek Goreng H. Slamet Asli Cab. Kartosuro", "latitude": 0.49990641033608602, "longitude": 101.44875226793211, "Alamat": "Jl. Cendrawasih No.88c Tengkerang Tengah Kec. Marpoyan Damai Kota Pekanbaru Riau 28128", "jam operas": "senin-jum'at", "Name": "ru2.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.448752267932107, 0.499906410336086 ] } },
{ "type": "Feature", "properties": { "id": "3", "nama": "Rumah Makan Pak Abbas", "latitude": 0.49349171060102298, "longitude": 101.39370976793214, "Alamat": "JL. SM. Amin Simpang Baru Kec. Tampan Kota Pekanbaru Riau 28292", "jam operas": "senin-jum'at", "Name": "ru3.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.393709767932137, 0.493491710601023 ] } },
{ "type": "Feature", "properties": { "id": "4", "nama": "Rumah Makan Beringin Eddy", "latitude": 0.524096337694267, "longitude": 101.43695603909589, "Alamat": "Jl. Dahlia No.37 Harjosari Kec. Sukajadi Kota Pekanbaru Riau 28156", "jam operas": "senin-jum'at", "Name": "ru4.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.43695603909589, 0.524096337694267 ] } },
{ "type": "Feature", "properties": { "id": "5", "nama": "Rumah makan Ranah Bundo Mulya", "latitude": 0.51723220960373395, "longitude": 101.41815335258748, "Alamat": "Jl. Darma Bakti No.Kelurahan Labuh Baru Bar. Kec. Payung Sekaki Kota Pekanbaru Riau 28292", "jam operas": "senin-jum'at", "Name": "ru5.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.418153352587481, 0.517232209603734 ] } }
]
}
