var json_shpsmp_4 = {
"type": "FeatureCollection",
"name": "shpsmp_4",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "1", "nama": "SMP Negeri 32 Pekanbaru", "latitude": 0.5091963, "longitude": 101.4335409, "Alamat": "Jl. Balam Ujung No.18 Kp. Melayu Kec. Sukajadi Kota Pekanbaru Riau 28122", "Jam Operas": "Sen-Jum", "Foto": "smp1.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.4335409, 0.5091963 ] } },
{ "type": "Feature", "properties": { "id": "2", "nama": "SMP Negeri 1 Pekanbaru", "latitude": 0.5264529, "longitude": 101.4519358, "Alamat": "GFG3+HJH Jl. St. Syarif Rintis Kec. Lima Puluh Kota Pekanbaru Riau 28156", "Jam Operas": "Sen-Jum", "Foto": "smp2.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.4519358, 0.5264529 ] } },
{ "type": "Feature", "properties": { "id": "3", "nama": "SMP Negeri 3 Pekanbaru", "latitude": 0.5242732, "longitude": 101.4298246, "Alamat": "Jl. Dahlia No.102 Kedungsari Kec. Sukajadi Kota Pekanbaru Riau 28123", "Jam Operas": "Sen-Jum", "Foto": "smp3.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.4298246, 0.5242732 ] } },
{ "type": "Feature", "properties": { "id": "4", "nama": "SMP Negeri 8 Pekanbaru", "latitude": 0.4744693, "longitude": 101.4384885, "Alamat": "Jl. Adi Sucipto No.115 Maharatu Kec. Marpoyan Damai Kota Pekanbaru Riau 28289", "Jam Operas": "Sen-Jum", "Foto": "smp4.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.4384885, 0.4744693 ] } },
{ "type": "Feature", "properties": { "id": "5", "nama": "SMP Negeri 22 Pekanbaru", "latitude": 0.5018027, "longitude": 101.4754326, "Alamat": "Jl. Sidodadi No.32 Tengkerang Utara Kec. Bukit Raya Kota Pekanbaru Riau 28289", "Jam Operas": "Sen-Jum", "Foto": "smp5.JPG" }, "geometry": { "type": "Point", "coordinates": [ 101.4754326, 0.5018027 ] } }
]
}
